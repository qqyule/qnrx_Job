<?php
class Setup{
    public function run(){
        $menu_mod = D('Menu');
        if($id = $menu_mod->where(array('name'=>'行为分析','module_name'=>'Admin','controller_name'=>'Company','action_name'=>'analyze_list_com'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('module_name','Analyze');
            $menu_mod->where(array('id'=>$id))->setfield('controller_name','Admin');
        }
        $menuDate = $menu_mod->field('id,pid')->where()->select();
        foreach($menuDate as $val){
            $menu[$val['pid']][] = $val['id'];
        }
        $this->_menu_spid($menu);
        $menu_mod->update_cache();
        $reg = D('AdminAuthGroup')->menu_group_init();
    }
    protected function _menu_spid(&$menu,$pid=0,$spid=''){
        $menu_mod = M('Menu');
        foreach($menu[$pid] as $val){
            if($pid){
                $spidStr = $spid.$val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }else{
                $spidStr = $val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }
            if($menu[$val]) $this->_menu_spid($menu,$val,$spidStr);
        }
    }
}
?>