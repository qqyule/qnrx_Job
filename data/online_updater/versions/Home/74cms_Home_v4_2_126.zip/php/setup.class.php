<?php
class Setup{
    public function run(){
        $menu_mod = D('Menu');
        $menu = $menu_mod->where(array('name'=>'内容','module_name'=>'Admin','controller_name'=>'Article','action_name'=>'index'))->find();
        if(!$id = $menu_mod->where(array('name'=>'事业单位招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'index'))->getfield('id')){
            $id = $menu_mod->add(array('name'=>'事业单位招考','pid'=>$menu['id'],'module_name'=>'Career','controller_name'=>'Admin','action_name'=>'index','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255,'img'=>'1204.png'));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if($menu = $menu_mod->where(array('name'=>'事业单位招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'index'))->find()){
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'招考列表','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'index'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'招考列表','pid'=>$menu['id'],'module_name'=>'Career','controller_name'=>'Admin','action_name'=>'index','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'添加招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'add'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'添加招考','pid'=>$menu['id'],'module_name'=>'Career','controller_name'=>'Admin','action_name'=>'add','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if($menu = $menu_mod->where(array('name'=>'招考列表','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'index'))->find()){
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'修改招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'edit'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'修改招考','pid'=>$menu['id'],'module_name'=>'Career','controller_name'=>'Admin','action_name'=>'edit','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'删除招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'delete'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'删除招考','pid'=>$menu['id'],'module_name'=>'Career','controller_name'=>'Admin','action_name'=>'delete','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
            }
        }
        $menu = $menu_mod->where(array('name'=>'内容','module_name'=>'Admin','controller_name'=>'Article','action_name'=>'index'))->find();
        if(!$id = $menu_mod->where(array('name'=>'企业专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'index'))->getfield('id')){
            $id = $menu_mod->add(array('name'=>'企业专访','pid'=>$menu['id'],'module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'index','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255,'img'=>'1203.png'));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if($menu = $menu_mod->where(array('name'=>'企业专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'index'))->find()){
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'专访列表','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'index'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'专访列表','pid'=>$menu['id'],'module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'index','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'添加专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'add'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'添加专访','pid'=>$menu['id'],'module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'add','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if($menu = $menu_mod->where(array('name'=>'专访列表','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'index'))->find()){
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'修改专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'edit'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'修改专访','pid'=>$menu['id'],'module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'edit','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'删除专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'delete'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'删除专访','pid'=>$menu['id'],'module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'delete','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
            }
        }
        $menu = $menu_mod->where(array('name'=>'内容','module_name'=>'Admin','controller_name'=>'Article','action_name'=>'index'))->find();
        if(!$id = $menu_mod->where(array('name'=>'专题招聘会','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'index'))->getfield('id')){
            $id = $menu_mod->add(array('name'=>'专题招聘会','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'index','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255,'img'=>'1205.png'));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if($menu = $menu_mod->where(array('name'=>'专题招聘会','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'index'))->find()){
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'专题列表','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'index'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'专题列表','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'index','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'添加专题','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'add'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'添加专题','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'add','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if($menu = $menu_mod->where(array('name'=>'专题列表','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'index'))->find()){
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'修改专题','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'edit'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'修改专题','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'edit','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'删除专题','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'delete'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'删除专题','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'delete','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
                if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'企业','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company'))->getfield('id')){
                    $id = $menu_mod->add(array('name'=>'企业','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                    $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                }
                if($menu = $menu_mod->where(array('name'=>'企业','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company'))->find()){
                    if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'专题企业列表','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company'))->getfield('id')){
                        $id = $menu_mod->add(array('name'=>'专题企业列表','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                        $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                    }
                    if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'添加企业','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company_add'))->getfield('id')){
                        $id = $menu_mod->add(array('name'=>'添加企业','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company_add','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                        $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
                    }

                }
            }
        }
        $menus = $menu_mod->where(array('name'=>'工具','module_name'=>'Admin','controller_name'=>'Database','action_name'=>'index'))->find();
        if($menu = $menu_mod->where(array('name'=>'风格模板','module_name'=>'Admin','controller_name'=>'Tpl','action_name'=>'index','pid'=>$menus['id']))->find()){
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'专题招聘会模板','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_tpl'))->getfield('id')){
                        $id = $menu_mod->add(array('name'=>'专题招聘会模板','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_tpl','menu_type'=>1,'is_parent'=>0,'display'=>1,'ordid'=>255));
                        $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
        }
        $menuDate = $menu_mod->field('id,pid')->where()->select();
        foreach($menuDate as $val){
            $menu[$val['pid']][] = $val['id'];
        }
        $this->_menu_spid($menu);
        $menu_mod->update_cache();
        $reg = D('AdminAuthGroup')->menu_group_init();
    }
    protected function _menu_spid(&$menu,$pid=0,$spid=''){
        $menu_mod = M('Menu');
        foreach($menu[$pid] as $val){
            if($pid){
                $spidStr = $spid.$val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }else{
                $spidStr = $val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }
            if($menu[$val]) $this->_menu_spid($menu,$val,$spidStr);
        }
    }
}
?>