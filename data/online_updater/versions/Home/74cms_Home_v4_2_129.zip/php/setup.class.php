<?php
class Setup{
    public function run(){
        if($sms = M('SmsTemplates')->where(array('alias'=>'set_invite','name'=>'邀请面试','type'=>'qscms'))->find()){
            M('SmsTemplates')->where(array('id'=>$sms['id']))->setfield('value','经查阅您投递的简历符合{companyname}要求，请登录{sitedomain}查看
         ');
        }
		$menu_mod = D('Menu');
        $menu = $menu_mod->where(array('name'=>'企业会员','module_name'=>'Admin','controller_name'=>'CompanyMembers','action_name'=>'index'))->find();
        if(!$id = $menu_mod->where(array('name'=>'解绑记录','module_name'=>'Admin','controller_name'=>'CompanyMembers','action_name'=>'unbind_mobile','pid'=>$menu['id']))->getfield('id')){
            $id = $menu_mod->add(array('name'=>'解绑记录','pid'=>$menu['id'],'module_name'=>'Admin','controller_name'=>'CompanyMembers','action_name'=>'unbind_mobile','menu_type'=>1,'is_parent'=>1,'display'=>1,'ordid'=>255));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        $menu_mod->where(array('name'=>'解绑记录'))->setfield('ordid',256);
        $menuDate = $menu_mod->field('id,pid')->where()->select();
        foreach($menuDate as $val){
            $menu[$val['pid']][] = $val['id'];
        }
        $this->_menu_spid($menu);
        $menu_mod->update_cache();
        $reg = D('AdminAuthGroup')->menu_group_init();
    }
	protected function _menu_spid(&$menu,$pid=0,$spid=''){
        $menu_mod = M('Menu');
        foreach($menu[$pid] as $val){
            if($pid){
                $spidStr = $spid.$val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }else{
                $spidStr = $val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }
            if($menu[$val]) $this->_menu_spid($menu,$val,$spidStr);
        }
    }
}
?>