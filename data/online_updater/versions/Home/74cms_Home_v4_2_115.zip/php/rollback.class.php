<?php
class Setup{
    public function run(){
        $table_mod = D('AdminLog');
        $field = $table_mod->getDbFields();
        if(in_array('log_url',$field)){
            $table_mod->execute("ALTER TABLE `".C('DB_PREFIX')."admin_log` modify column `log_url` varchar(255) ");
        }
    }
}
?>