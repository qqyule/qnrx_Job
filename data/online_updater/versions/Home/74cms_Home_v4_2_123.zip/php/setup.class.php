<?php
class Setup{
    public function run(){
        if(!D('Config')->where(array('name'=>'apply_jobs_contact'))->find()){
            $setsqlarr['name'] = 'apply_jobs_contact';
            $setsqlarr['value'] = '';
            $setsqlarr['note'] = '投递简历后联系方式是否显示';
            D('Config')->add($setsqlarr);
        } 
    }
}
?>