<?php
class Setup{
    public function run(){
        if(D('Config')->where(array('name'=>'apply_jobs_contact'))->find()){
            D('Config')->where(array('name'=>'apply_jobs_contact'))->delete();
        }
    }
}
?>