<?php
class Setup{
    public function run(){
        $menu_mod = D('Menu');
        if($id = $menu_mod->where(array('name'=>'投诉建议','module_name'=>'Admin','controller_name'=>'Report','action_name'=>'index'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('stat','report');
        }
        if($id = $menu_mod->where(array('name'=>'删除会员','module_name'=>'Admin','controller_name'=>'CompanyMembers','action_name'=>'delete_company_members'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('action_name','delete');
        }
        if($id = $menu_mod->where(array('name'=>'删除会员弹窗','module_name'=>'Admin','controller_name'=>'Ajax','action_name'=>'delete_company'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->delete();
        }
        if($id = $menu_mod->where(array('name'=>'审核简历弹窗','module_name'=>'Admin','controller_name'=>'Ajax','action_name'=>'resumes_audit'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->delete();
        }
        if(!$id = $menu_mod->where(array('name'=>'保存修改导航','module_name'=>'Admin','controller_name'=>'Navigation','action_name'=>'nav_all_save'))->getfield('id')){
            $menu = $menu_mod->where(array('name'=>'导航菜单','module_name'=>'Admin','controller_name'=>'Navigation','action_name'=>'index'))->find();
            $id = $menu_mod->add(array('name'=>'保存修改导航','pid'=>$menu['id'],'module_name'=>'Admin','controller_name'=>'Navigation','action_name'=>'nav_all_save','menu_type'=>0,'display'=>1,'ordid'=>255));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if(!$id = $menu_mod->where(array('name'=>'企业认证图片弹窗','module_name'=>'Admin','controller_name'=>'Ajax','action_name'=>'img_audit'))->getfield('id')){
            $menu = $menu_mod->where(array('name'=>'企业风采','module_name'=>'Admin','controller_name'=>'CompanyImg','action_name'=>'index'))->find();
            $id = $menu_mod->add(array('name'=>'企业认证图片弹窗','pid'=>$menu['id'],'module_name'=>'Admin','controller_name'=>'Ajax','action_name'=>'img_audit','menu_type'=>0,'display'=>1,'ordid'=>255));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if(!$id = $menu_mod->where(array('name'=>'审核简历弹窗','module_name'=>'Admin','controller_name'=>'Ajax','action_name'=>'resumes_audit'))->getfield('id')){
            $menu = $menu_mod->where(array('name'=>'简历列表','module_name'=>'Admin','controller_name'=>'Personal','action_name'=>'index'))->find();
            $id = $menu_mod->add(array('name'=>'审核简历弹窗','pid'=>$menu['id'],'module_name'=>'Admin','controller_name'=>'Ajax','action_name'=>'resumes_audit','menu_type'=>0,'display'=>1,'ordid'=>255));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if($menu = $menu_mod->where(array('name'=>'微信营销','module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'queue'))->find()){
            if(!$id = $menu_mod->where(array('name'=>'添加任务','module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'queue_add'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'添加任务','pid'=>$menu['id'],'module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'queue_add','menu_type'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('name'=>'修改任务','module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'queue_edit'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'修改任务','pid'=>$menu['id'],'module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'queue_edit','menu_type'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('name'=>'删除任务','module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'delete_weixin_queue'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'删除任务','pid'=>$menu['id'],'module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'delete_weixin_queue','menu_type'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('name'=>'发送','module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'send_weixin_queue'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'发送','pid'=>$menu['id'],'module_name'=>'Weixin','controller_name'=>'Admin','action_name'=>'send_weixin_queue','menu_type'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
        }
        if(!$id = $menu_mod->where(array('name'=>'添加','module_name'=>'Store','controller_name'=>'Admin','action_name'=>'add_jobs'))->getfield('id')){
            $menu = $menu_mod->where(array('name'=>'招聘信息','module_name'=>'Store','controller_name'=>'Admin','action_name'=>'index'))->find();
            $id = $menu_mod->add(array('name'=>'添加','pid'=>$menu['id'],'module_name'=>'Store','controller_name'=>'Admin','action_name'=>'add_jobs','menu_type'=>0,'img'=>'','display'=>1,'ordid'=>0));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if(!$id = $menu_mod->where(array('name'=>'添加','module_name'=>'Store','controller_name'=>'Admin','action_name'=>'add_rent'))->getfield('id')){
            $menu = $menu_mod->where(array('name'=>'转租信息','module_name'=>'Store','controller_name'=>'Admin','action_name'=>'rent'))->find();
            $id = $menu_mod->add(array('name'=>'添加','pid'=>$menu['id'],'module_name'=>'Store','controller_name'=>'Admin','action_name'=>'add_rent','menu_type'=>0,'img'=>'','display'=>1,'ordid'=>0));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        if(!$id = $menu_mod->where(array('name'=>'添加','module_name'=>'Store','controller_name'=>'Admin','action_name'=>'add_seek'))->getfield('id')){
            $menu = $menu_mod->where(array('name'=>'求租信息','module_name'=>'Store','controller_name'=>'Admin','action_name'=>'seek'))->find();
            $id = $menu_mod->add(array('name'=>'添加','pid'=>$menu['id'],'module_name'=>'Store','controller_name'=>'Admin','action_name'=>'add_seek','menu_type'=>0,'img'=>'','display'=>1,'ordid'=>0));
            $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
        }
        $menuDate = $menu_mod->field('id,pid')->where()->select();
        foreach($menuDate as $val){
            $menu[$val['pid']][] = $val['id'];
        }
        $this->_menu_spid($menu);
        $menu_mod->update_cache();
        $reg = D('AdminAuthGroup')->menu_group_init();
    }
    protected function _menu_spid(&$menu,$pid=0,$spid=''){
        $menu_mod = M('Menu');
        foreach($menu[$pid] as $val){
            if($pid){
                $spidStr = $spid.$val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }else{
                $spidStr = $val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }
            if($menu[$val]) $this->_menu_spid($menu,$val,$spidStr);
        }
    }
}
?>