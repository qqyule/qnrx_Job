<?php
class Setup{
    public function run(){
        $file = QSCMS_DATA_PATH.'upload/'.'ads';
        $rename = QSCMS_DATA_PATH.'upload/'.'attach_img';
        @rename($file,$rename);         
    }
}
?>