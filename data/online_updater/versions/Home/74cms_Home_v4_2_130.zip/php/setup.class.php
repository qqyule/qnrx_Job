<?php
class Setup{
    public function run(){
        if($sms = M('SmsTemplates')->where(array('alias'=>'set_invite','name'=>'邀请面试','type'=>'qscms'))->find()){
            M('SmsTemplates')->where(array('id'=>$sms['id']))->setfield('value','经查阅您投递的简历符合{companyname}要求，请登录{sitedomain}查看');
        }
        $menu_mod = D('Menu');
        if($id = $menu_mod->where(array('name'=>'修改招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'edit'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($id = $menu_mod->where(array('name'=>'删除招考','module_name'=>'Career','controller_name'=>'Admin','action_name'=>'delete'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($id = $menu_mod->where(array('name'=>'修改专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'edit'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($id = $menu_mod->where(array('name'=>'删除专访','module_name'=>'Interview','controller_name'=>'Admin','action_name'=>'delete'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }  
        if($id = $menu_mod->where(array('name'=>'修改专题','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'edit'))->getfield('id')){      
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($id = $menu_mod->where(array('name'=>'删除专题','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'delete'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($id = $menu_mod->where(array('name'=>'企业','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($id = $menu_mod->where(array('name'=>'添加企业','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company_add'))->getfield('id')){
            $menu_mod->where(array('id'=>$id))->setfield('menu_type',0);
        }
        if($menu = $menu_mod->where(array('name'=>'企业','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company'))->find()){
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'专题Ajax获取职位','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'ajax_get_jobs'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'专题Ajax获取职位','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'ajax_get_jobs','menu_type'=>0,'is_parent'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
            if(!$id = $menu_mod->where(array('pid'=>$menu['id'],'name'=>'专题删除职位','module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company_delete'))->getfield('id')){
                $id = $menu_mod->add(array('name'=>'专题删除职位','pid'=>$menu['id'],'module_name'=>'Subject','controller_name'=>'Admin','action_name'=>'subject_company_delete','menu_type'=>0,'is_parent'=>0,'display'=>1,'ordid'=>255));
                $menu_mod->where(array('id'=>$id))->setfield('spid',$menu['spid'].$id.'|');
            }
        }
        $menuDate = $menu_mod->field('id,pid')->where()->select();
        foreach($menuDate as $val){
            $menu[$val['pid']][] = $val['id'];
        }
        $this->_menu_spid($menu);
        $menu_mod->update_cache();
        $reg = D('AdminAuthGroup')->menu_group_init();
    }
    protected function _menu_spid(&$menu,$pid=0,$spid=''){
        $menu_mod = M('Menu');
        foreach($menu[$pid] as $val){
            if($pid){
                $spidStr = $spid.$val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }else{
                $spidStr = $val.'|';
                $menu_mod->where(array('id'=>$val))->setfield('spid',$spidStr);
            }
            if($menu[$val]) $this->_menu_spid($menu,$val,$spidStr);
        }
    }
}
?>