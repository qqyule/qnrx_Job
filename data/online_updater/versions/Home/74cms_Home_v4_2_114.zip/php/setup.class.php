<?php
class Setup{
    public function run(){
        if(D('Task')->where(array('title'=>'完善基本资料','t_alias'=>'user_info','utype'=>'2'))->find()){
            D('Task')->where(array('title'=>'完善基本资料','t_alias'=>'user_info','utype'=>'2'))->delete();
        }
        if(D('Task')->where(array('title'=>'邀请注册','t_alias'=>'invitation_reg','utype'=>'2'))->find()){
            D('Task')->where(array('title'=>'邀请注册','t_alias'=>'invitation_reg','utype'=>'2'))->delete();
        }
        if(D('Task')->where(array('title'=>'推荐注册','t_alias'=>'invitation_reg','utype'=>'1'))->find()){
            D('Task')->where(array('title'=>'推荐注册','t_alias'=>'invitation_reg','utype'=>'1'))->delete();
        }
        if(D('Task')->where(array('title'=>'绑定淘宝账号','t_alias'=>'binding_taobao','utype'=>'2'))->find()){
            D('Task')->where(array('title'=>'绑定淘宝账号','t_alias'=>'binding_taobao','utype'=>'2'))->delete();
        }
        if(D('Task')->where(array('title'=>'绑定淘宝账号','t_alias'=>'binding_taobao','utype'=>'1'))->find()){
            D('Task')->where(array('title'=>'绑定淘宝账号','t_alias'=>'binding_taobao','utype'=>'1'))->delete();
        }
    }
}
?>