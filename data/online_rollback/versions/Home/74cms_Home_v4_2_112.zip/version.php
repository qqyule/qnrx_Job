<?php
	return array(
		'module'				=>	'Home',				//应用别名
		'module_name'			=>	'骑士人才系统核心模块',	//应用名称
		'appid'					=>	'',
		'version'				=>	'4.2.111',			//版本号
		'is_create_table'		=>	0,					//是否需要创建数据表
		'is_insert_data'		=>	0,					//是否需要添加数据
		'is_exe'				=>	0,					//是否有其它逻辑程序
		'is_delete_data'		=>	0,
		'update_time'			=>	'2018-03-22 15:00',	//当前版本更新时间
		'explain'				=>	'此模块为骑士人才系统基础模块，安装其他周边模块必须在此模块的基础上增加，模块包含了系统的招聘求职等核心功能。'//说明
	);
?>