<?php
	return array(
		'personal_jobs_subscribe_null_error_title' => '请填写订阅名称！',
		'personal_jobs_subscribe_null_error_key' => '请填写关健字！',
		'personal_jobs_subscribe_null_error_trade' => '请选择行业分类！',
		'personal_jobs_subscribe_null_error_intention_jobs_id' => '请选择职能分类！',
		'personal_jobs_subscribe_null_error_district' => '请选择工作地点！',
		'title_length_error' => '订阅名称长度应在1~30个字之间！',
		'key_length_error' => '订阅关健字长度应在1~20个字之间！',
		'personal_jobs_subscribe_format_error_trade' => '请正确选择行业分类！',
		'personal_jobs_subscribe_format_error_intention_jobs_id' => '请正确选择职能分类！',
		'personal_jobs_subscribe_format_error_district' => '请正确选择工作地点！',
		'personal_jobs_subscribe_format_error_wage' => '请正确选择年薪范围！',
	);
?>